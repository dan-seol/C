 #include <stdio.h>
 #include <string.h>
#include <stdlib.h>
 #include <limits.h>
#include <math.h>
// It can take multiple downloaded pages at once.
//EXAMPLE OUTPUT from
// $  ./a.out Bird Jurassic
// Here is your 1-th article.This is a featured article. Click here for more information.
//
// This article is semi-protected.
//
// Listen to this article
//
// Bird (disambiguation)
//
// Birds (disambiguation)
//
// Aves (disambiguation)
//
// Avifauna (disambiguation)
//
// Early Cretaceous
//
// Holocene
//
// Precambrian
//
// Cambrian
//
// Ordovician
//
// Silurian
//
// Devonian
//
// Carboniferous
//
// Permian
//
// Triassic
//
// Jurassic
//
// Cretaceous
//
// Paleogene
//
// Neogene
//
// About this image
//
// Taxonomy (biology)
//
// edit
//
// Animal
//
// Chordate
//
// Ornithurae
//
// Carl Linnaeus
//
// 10th edition of Systema Naturae
//
// Order (biology)
//
// Palaeognathae
//
// Struthioniformes
//
// Notopalaeognathae
//
// Rheiformes
//
// Tinamiformes
//
// Casuariiformes
//
// Apterygiformes
//
// Neognathae
//
// Galloanserae
//
// Galliformes
//
// Anseriformes
//
// Neoaves
//
// Phoenicopteriformes
//
// Podicipediformes
//
// Columbiformes
//
// Mesitornithiformes
//
// Pteroclidiformes
//
// Apodiformes
//
// Caprimulgiformes
//
// Cuculiformes
//
// Otidiformes
//
// Musophagiformes
//
// Opisthocomiformes
//
// Gruiformes
//
// Charadriiformes
//
// Gaviiformes
//
// Procellariiformes
//
// Sphenisciformes
//
// Ciconiiformes
//
// Suliformes
//
// Pelecaniformes
//
// Eurypygiformes
//
// Phaethontiformes
//
// Cathartiformes
//
// Accipitriformes
//
// Strigiformes
//
// Coliiformes
//
// Leptosomiformes
//
// Trogoniformes
//
// Bucerotiformes
//
// Coraciiformes
//
// Piciformes
//
// Cariamiformes
//
// Falconiformes
//
// Psittaciformes
//
// Passeriformes
//
// Synonym (taxonomy)
//
// Endotherm
//
// Vertebrate
//
// Feather
//
// Tooth
//
// Beak
//
// Oviparity
//
// Eggshell
//
// Metabolic
//
// Heart
//
// Bird skeleton
//
// Bee hummingbird
//
// Common ostrich
//
// Class (biology)
//
// Tetrapod
//
// Passerine
//
// Glossary of bird terms
//
// Extinct
//
// Moa
//
// Elephant bird
//
// Forelimb
//
// Bird flight
//
// Flightless bird
//
// Ratite
//
// Penguin
//
// Endemism in birds
//
// Digestion
//
// Respiratory system
//
// Seabird
//
// Water bird
//
// Aquatic locomotion
//
// Fossil
//
// Dinosaurs
//
// Feathered dinosaur
//
// Theropod
//
// Saurischia
//
// Crocodilia
//
// Avialae
//
// Jurassic
//
// Archaeopteryx
//
// Cretaceous–Paleogene extinction event
//
// Pterosaur
//
// Dinosaur
//
// Cladistics
//
// Corvids
//
// Parrot
//
// Intelligent animal
//
// Tool use by animals
//
// Social animal
//
// Culture
//
// Bird migration
//
// Bird vocalization
//
// Helpers at the nest
//
// Flocking (behavior)
//
// Mobbing (animal behavior)
//
// Socially monogamous
//
// Polyandry
//
// Polyandry
//
// Egg
//
// Sexual reproduction
//
// Bird nest
//
// Avian incubation
//
// Chicken
//
// Food
//
// Poultry
//
// Game (hunting)
//
// Songbird
//
// Guano
//
// Fertilizer
//
// List of fictional birds
//
// Bird conservation
//
// Birdwatching
//
// Ecotourism
//
// Evolution of birds
//
// Enlarge
//
// Enlarge
//
// Archaeopteryx lithographica
//
// Biological classification
//
// Francis Willughby
//
// John Ray
//
// Carl Linnaeus
//
// Taxonomic classification
//
// Class (biology)
//
// Linnaean taxonomy
//
// Phylogenetic taxonomy
//
// Clade
//
// Theropoda
//
// Crocodilia
//
// Archosauria
//
// Phylogenetics
//
// Most recent common ancestor
//
// Archaeopteryx
//
// Jacques Gauthier
//
// Phylocode
//
// Crown group
//
// Crown group
//
// Crocodile
//
// Turtle
//
// Lizard
//
// Snake
//
// Archosaur
//
// Crocodile
//
// Avemetatarsalia
//
// Avifilopluma
//
// Avialae
//
// Theropod
//
// Deinonychus
//
// Phylogenetic nomenclature
//
// Jacques Gauthier
//
// Wing
//
// Bird flight
//
// Origin of birds
//
// Enlarge
//
// Enlarge
//
// Anchiornis huxleyi
//
// Late Jurassic
//
// Paraves
//
// Scansoriopterygidae
//
// Eosinopteryx
//
// Eumaniraptora
//
// Jinfengopteryx
//
// Aurornis
//
// Dromaeosauridae
//
// Troodontidae
//
// Avialae
//
// Theropod
//
// Dinosaur
//
// Maniraptora
//
// Dromaeosaur
//
// Oviraptorid
//
// Liaoning
//
// Feathered dinosaurs 
//
// Paleontology
//
// Avialae
//
// Deinonychosaur
//
// Troodontid
//
// Paraves
//
// Basal (phylogenetics)
//
// Microraptor
//
// Arboreal
//
// Omnivore
//
// Late Jurassic
//
// Transitional fossil
//
// Theory of evolution
//
// List of fossil bird genera
//
// Enlarge
//
// Enlarge
//
// Confuciusornis sanctus
//
// Avialae
//
// Anchiornis
//
// Archaeopteryx
//
// Xiaotingia
//
// Rahonavis
//
// Jeholornis
//
// Jixiangornis
//
// Euavialae
//
// Balaur bondoc
//
// Avebrevicauda
//
// Zhongjianornis
//
// Sapeornis
//
// Pygostylia
//
// Confuciusornithiformes
//
// Protopteryx
//
// Pengornis
//
// Ornithothoraces
//
// Tiaojishan Formation
//
// Jurassic
//
// Oxfordian (stage)
//
// Anchiornis huxleyi
//
// Xiaotingia zhengi
//
// Aurornis xui
//
// Germany
//
// Cretaceous Period
//
// Symplesiomorphy
//
// Jeholornis
//
// Pygostyle
//
// Pygostylia
//
// Enlarge
//
// Enlarge
//
// Ichthyornis
//
// Ornithothoraces
//
// Enantiornithes
//
// Euornithes
//
// Archaeorhynchus
//
// Ornithuromorpha
//
// Patagopteryx
//
// Vorona
//
// Schizooura
//
// Hongshanornithidae
//
// Jianchangornis
//
// Songlingornithidae
//
// Gansus
//
// Apsaravis
//
// Ornithurae
//
// Hesperornithes
//
// Ichthyornis
//
// Vegavis
//
// Enantiornithes
//
// Mesozoic
//
// Euornithes
//
// Gull
//
// Ichthyornis
//
// Hesperornithiformes
//
// Pygostyle
//
// Mosaic evolution
//
// Most recent common ancestor
//
// Hook-billed vanga
//
// Eurasian golden oriole
//
// Sibley–Ahlquist taxonomy of birds
//
// Dinosaur classification
//
// Palaeognathae
//
// Struthioniformes
//
// Tinamiformes
//
// Neognathae
//
// Neoaves
//
// Galloanserae
//
// Anseriformes
//
// Galliformes
//
// Sibley-Ahlquist taxonomy
//
// Crown group
//
// Palaeognathae
//
// Ratite
//
// Ostrich
//
// Tinamou
//
// Neognathae
//
// Taxonomic rank
//
// Superorder
//
// Bradley C. Livezey
//
// Alpha taxonomy
//
// Vegavis
//
// Anatidae
//
// Cenozoic
//
// Cretaceous
//
// Middle Cretaceous
//
// Late Cretaceous
//
// Cretaceous–Paleogene extinction event
//
// Fossil
//
// Cenozoic
//
// Molecular clocks
//
// Late Cretaceous
//
// Cretaceous–Paleogene extinction event
//
// List of birds
//
// Cladogram
//
// Clade
//
// Palaeognathae
//
// Struthioniformes
//
// Ostrich
//
// Notopalaeognathae
//
// Notopalaeognathae
//
// Rheiformes
//
// Rhea (bird)
//
// Novaeratitae
//
// Novaeratitae
//
// Casuariiformes
//
// Cassowary
//
// Emu
//
// Apterygiformes
//
// Apterygiformes
//
// Kiwi
//
// Aepyornithiformes
//
// Aepyornithiformes
//
// Elephant bird
//
// Tinamiformes
//
// Tinamiformes
//
// Tinamou
//
// Dinornithiformes
//
// Dinornithiformes
//
// Moa
//
// Neognathae
//
// Neognathae
//
// Galloanserae
//
// Galliformes
//
// Anseriformes
//
// Anseriformes
//
// Neoaves
//
// Neoaves
//
// Strisores
//
// Caprimulgiformes
//
// Caprimulgidae
//
// Nyctibiiformes
//
// Steatornithidae
//
// Oilbird
//
// Nyctibiidae
//
// Potoos
//
// Podargiformes
//
// Podargidae
//
// Apodiformes
//
// Columbaves
//
// Columbaves
//
// Otidimorphae
//
// Musophagiformes
//
// Otidiformes
//
// Otidiformes
//
// Cuculiformes
//
// Cuculiformes
//
// Columbimorphae
//
// Columbimorphae
//
// Columbiformes
//
// Mesitornithiformes
//
// Mesitornithiformes
//
// Pteroclidiformes
//
// Pteroclidiformes
//
// Gruiformes
//
// Gruiformes
//
// Aequorlitornithes
//
// Aequorlitornithes
//
// Mirandornithes
//
// Phoenicopteriformes
//
// Podicipediformes
//
// Podicipediformes
//
// Charadriiformes
//
// Charadriiformes
//
// Ardeae
//
// Ardeae
//
// Eurypygimorphae
//
// Phaethontiformes
//
// Eurypygiformes
//
// Eurypygiformes
//
// Aequornithes
//
// Aequornithes
//
// Gaviiformes
//
// Loon
//
// Austrodyptornithes
//
// Procellariiformes
//
// Sphenisciformes
//
// Ciconiiformes
//
// Ciconiiformes
//
// Suliformes
//
// Suliformes
//
// Cormorant
//
// Pelecaniformes
//
// Pelican
//
// Heron
//
// Egret
//
// Inopinaves
//
// Inopinaves
//
// Opisthocomiformes
//
// Telluraves
//
// Telluraves
//
// Accipitrimorphae
//
// Cathartiformes
//
// Accipitriformes
//
// Accipitriformes
//
// Afroaves
//
// Afroaves
//
// Strigiformes
//
// Coraciimorphae
//
// Coraciimorphae
//
// Coliiformes
//
// Cavitaves
//
// Leptosomatiformes
//
// Eucavitaves
//
// Trogoniformes
//
// Picocoraciae
//
// Picocoraciae
//
// Bucerotiformes
//
// Coraciformes
//
// Coraciformes
//
// Piciformes
//
// Piciformes
//
// Australaves
//
// Australaves
//
// Cariamiformes
//
// Eufalconimorphae
//
// Eufalconimorphae
//
// Falconiformes
//
// Psittacopasserae
//
// Psittacopasserae
//
// Psittaciformes
//
// Passeriformes
//
// Passeriformes
//
// Charles Sibley
//
// Charles Sibley
//
// Jon Ahlquist
//
// Lists of birds by region
//
// List of birds by population
//
// Enlarge
//
// Enlarge
//
// House sparrow
//
// Snow petrel
//
// Antarctica
//
// Biodiversity
//
// Speciation
//
// Extinction
//
// Seabird
//
// Penguin
//
// Introduced species
//
// Ring-necked pheasant
//
// Game bird
//
// Monk parakeet
//
// Cattle egret
//
// Yellow-headed caracara
//
// Galah
//
// Avian range expansion
//
// Agriculture
//
// Bird anatomy
//
// Bird vision
//
// Egg tooth
//
// Enlarge
//
// Enlarge
//
// Yellow-wattled lapwing
//
// Covert (feather)
//
// Body plan
//
// Bird flight
//
// Respiratory system
//
// Cranial sutures
//
// Orbit (anatomy)
//
// Septum
//
// Vertebral column
//
// Thoracic vertebrae
//
// Pelvis
//
// Synsacrum
//
// Sternum
//
// Reptile
//
// Kidney
//
// Uric acid
//
// Urea
//
// Ammonia
//
// Urinary bladder
//
// Ostrich
//
// Creatine
//
// Creatinine
//
// Cloaca
//
// Bird anatomy
//
// Pellet (ornithology)
//
// Palaeognathae
//
// Kiwi
//
// Anseriformes
//
// Screamer
//
// Galliformes
//
// Cracidae
//
// Bird penis
//
// Neoaves
//
// Sperm competition
//
// Proctodeum
//
// Digestive system
//
// Crop (anatomy)
//
// Gizzard
//
// Respiratory system
//
// Parabronchi
//
// Syrinx (biology)
//
// Aortic arches
//
// Aorta
//
// Red blood cells
//
// Cell nucleus
//
// Enlarge
//
// Enlarge
//
// Educational toy
//
// Serous fluid
//
// Atrium (heart)
//
// Ventricle (heart)
//
// Atrioventricular valves
//
// Sinoatrial node
//
// Endocardial
//
// Myocardial
//
// Epicardial
//
// Vasoconstriction
//
// Vasodilation
//
// Enlarge
//
// Enlarge
//
// Nictitating membrane
//
// Masked lapwing
//
// Nervous system
//
// Cerebellum
//
// Cerebrum
//
// Bird nest
//
// Olfaction
//
// Kiwi
//
// New World vulture
//
// Tubenoses
//
// Visual system
//
// Fovea centralis
//
// Tetrachromacy
//
// Ultraviolet
//
// Cone cell
//
// Double cone (biology)
//
// Monochromacy
//
// Ultraviolet
//
// Blue tit
//
// Kestrel
//
// Nictitating membrane
//
// Contact lens
//
// Retina
//
// Pecten oculi
//
// Great cormorant
//
// Visual field
//
// Binocular vision
//
// Depth of field
//
// Ear
//
// Pinna (anatomy)
//
// Asio
//
// Horned owl
//
// Scops owl
//
// Owl
//
// Inner ear
//
// Cochlea
//
// Procellariiformes
//
// Stomach oil
//
// Pitohui
//
// New Guinea
//
// Neurotoxin
//
// Anhimidae
//
// Jacana (genus)
//
// Hydrophasianus
//
// Plectropterus
//
// Merganetta
//
// Vanellus
//
// Tachyeres
//
// Anserinae
//
// Pezophaps
//
// Chionis
//
// Crax
//
// Burhinus
//
// Alula
//
// Actophilornis
//
// Irediparra
//
// Xenicibis
//
// Cygnus olor
//
// Female
//
// Male
//
// ZW sex-determination system
//
// XY sex-determination system
//
// Mammal
//
// Temperature-dependent sex determination
//
// Australian brushturkey
//
// Sex ratio
//
// Feather
//
// Flight feather
//
// Enlarge
//
// Enlarge
//
// Disruptively patterned
//
// African scops owl
//
// Feathered dinosaurs
//
// Bird flight
//
// Thermoregulation
//
// Pterylography
//
// Plumage
//
// Social status
//
// Sexual dimorphism
//
// Moult
//
// Glossary of bird terms
//
// Humphrey-Parkes terminology
//
// Glossary of bird terms
//
// Glossary of bird terms
//
// Flight feather
//
// Glossary of bird terms
//
// Glossary of bird terms
//
// Glossary of bird terms
//
// Glossary of bird terms
//
// Phasianidae
//
// Woodpecker
//
// Treecreeper
//
// Passerine
//
// Brood patch
//
// Enlarge
//
// Enlarge
//
// Red lory
//
// Wax
//
// Uropygial gland
//
// Antimicrobial
//
// Bacteria
//
// Formic acid
//
// Anting (bird activity)
//
// Bird anatomy
//
// Metatarsus
//
// Kingfisher
//
// Woodpecker
//
// Homology (biology)
//
// Bird flight
//
// Enlarge
//
// Enlarge
//
// Restless flycatcher
//
// Flying and gliding animals
//
// Wing
//
// Airfoil
//
// Flightless bird
//
// Auk
//
// Shearwater
//
// Dipper
//
// Diurnal animal
//
// Owl
//
// Nightjar
//
// Nocturnal
//
// Crepuscular
//
// Wader
//
// Enlarge
//
// Enlarge
//
// Glossary of bird terms
//
// Nectar (plant)
//
// Carrion
//
// Digestive system
//
// Mastication
//
// Gleaning (birds)
//
// Pest (organism)
//
// Insect
//
// Biological pest control
//
// Hummingbird
//
// Sunbird
//
// Lories and lorikeets
//
// Coevolution
//
// Kiwi
//
// Shorebird
//
// Ecological niche
//
// Loon
//
// Diving duck
//
// Penguin
//
// Auks
//
// Sulidae
//
// Kingfisher
//
// Tern
//
// Flamingo
//
// Prion (bird)
//
// Filter feeder
//
// Geese
//
// Dabbling duck
//
// Frigatebird
//
// Gull
//
// Skua
//
// Kleptoparasitism
//
// Great frigatebird
//
// Masked booby
//
// Scavenger
//
// Vulture
//
// Corvid
//
// Sweat gland
//
// Salt gland
//
// Columbidae
//
// Estrildidae
//
// Coliidae
//
// Turnicidae
//
// Otididae
//
// Sandgrouse
//
// Crop milk
//
// Ectoparasitic
//
// Bird louse
//
// Glossary of bird terms
//
// Glossary of bird terms
//
// Anting (bird activity)
//
// Bird migration
//
// Enlarge
//
// Enlarge
//
// Canada geese
//
// V formation
//
// Season
//
// Shorebird
//
// Waterbird
//
// Temperate
//
// Polar region
//
// Tropical
//
// Bar-tailed godwit
//
// Seabird
//
// Sooty shearwater
//
// New Zealand
//
// Chile
//
// Alaska
//
// California
//
// Albatross
//
// Southern Ocean
//
// Enlarge
//
// Enlarge
//
// Bar-tailed godwit
//
// New Zealand
//
// Finch
//
// Altitudinal migration
//
// Territory (animal)
//
// True parrots
//
// Family (biology)
//
// Manx shearwater
//
// Boston
//
// Skomer
//
// Diurnal animal
//
// Sun
//
// Chronobiology
//
// Constellation
//
// Polaris
//
// Geomagnetism
//
// Photoreceptor cell
//
// Bird vocalisation
//
// File:Troglodytes aedon - House Wren - XC79974.ogg
//
// House wren
//
// File:Tooth-billed Catbird audio09.ogg
//
// Tooth-billed bowerbird
//
// Spangled drongo
//
// File:Picidae pecking on wood.ogg
//
// Woodpecker
//
// Help:Media
//
// Enlarge
//
// Enlarge
//
// Sunbittern
//
// Animal communication
//
// Sunbittern
//
// Hawk
//
// Bird vocalization
//
// Syrinx (biology)
//
// Sound
//
// Coenocorypha
//
// Snipe
//
// New Zealand
//
// Woodpecker
//
// Palm cockatoo
//
// Enlarge
//
// Enlarge
//
// Red-billed quelea
//
// Flock (birds)
//
// Safety in numbers
//
// Ambush predation
//
// Mixed-species feeding flock
//
// Seabird
//
// Dolphin
//
// Tuna
//
// Hornbill
//
// Mutualism (biology)
//
// Dwarf mongoose
//
// Birds of prey
//
// Enlarge
//
// Enlarge
//
// American flamingo
//
// Swift
//
// Slow-wave sleep
//
// Cerebral hemisphere
//
// Predator
//
// Marine mammal
//
// Communal roosting
//
// Thermoregulation
//
// Beak
//
// Passerine
//
// Loriculus
//
// Hummingbird
//
// Torpor
//
// Adaptation
//
// Owlet-nightjar
//
// Nightjar
//
// Woodswallow
//
// Common poorwill
//
// Hibernation
//
// Urohidrosis
//
// Category:Avian sexuality
//
// Animal sexual behaviour
//
// Seabird breeding behaviour
//
// Sexual selection in birds
//
// Enlarge
//
// Enlarge
//
// Raggiana bird-of-paradise
//
// Paternal care
//
// Parental investment
//
// Forced copulation
//
// Anatidae
//
// Female sperm storage
//
// Sperm competition
//
// Polygyny
//
// Polyandry
//
// Polygamy
//
// Polygynandry
//
// Promiscuity
//
// Bird vocalization
//
// Lek (mating arena)
//
// Phalaropes
//
// Courtship feeding
//
// Billing (birds)
//
// Glossary of bird terms
//
// Homosexuality in animals
//
// Bird nest
//
// Seabird
//
// Swift
//
// Bird colony
//
// Amniotic egg
//
// Calcium carbonate
//
// Camouflage
//
// Nightjar
//
// Brood parasites
//
// Enlarge
//
// Enlarge
//
// Golden-backed weaver
//
// Bird nest
//
// Albatross
//
// Common guillemot
//
// Emperor penguin
//
// Precocial
//
// Enlarge
//
// Enlarge
//
// Eastern phoebe
//
// Brown-headed cowbird
//
// Egg incubation
//
// Brood patch
//
// Megapode
//
// Woodpecker
//
// Cuckoo
//
// Passerine
//
// Kiwi
//
// Ruby-throated hummingbird
//
// House sparrow
//
// Greater roadrunner
//
// Turkey vulture
//
// Laysan albatross
//
// Magellanic penguin
//
// Golden eagle
//
// Wild turkey
//
// Parental care in birds
//
// Altricial
//
// Blindness
//
// Precocial
//
// Thermoregulation
//
// Glossary of bird terms
//
// Glossary of bird terms
//
// Enlarge
//
// Enlarge
//
// Calliope hummingbird
//
// Enlarge
//
// Enlarge
//
// Altricial
//
// White-breasted woodswallow
//
// Megapode
//
// Great frigatebird
//
// Fledge
//
// Helpers at the nest
//
// Breeding pair
//
// Corvida
//
// Corvidae
//
// Australian magpie
//
// Fairy-wren
//
// Rifleman (bird)
//
// Red kite
//
// Paternal care
//
// Division of labour
//
// Fledge
//
// Synthliboramphus
//
// Ancient murrelet
//
// Bird migration
//
// Brood parasite
//
// Enlarge
//
// Enlarge
//
// Reed warbler
//
// Common cuckoo
//
// Brood parasite
//
// Brood parasitism
//
// Conspecific
//
// Honeyguide
//
// Icterid
//
// Black-headed duck
//
// Cuckoo
//
// Enlarge
//
// Enlarge
//
// Fisherian runaway
//
// Sexual selection in birds
//
// Evolution
//
// Mating
//
// Peafowl
//
// Sexual selection
//
// Fisherian runaway
//
// Sexual dimorphism
//
// Sexual selection
//
// Courtship behavior
//
// Inbreeding depression
//
// Inbreeding depression
//
// Zebra finch
//
// Sibling
//
// Darwin&#39;s finches
//
// Inbreeding depression
//
// Inbreeding avoidance
//
// Purple-crowned fairywren
//
// Inbreeding depression
//
// Promiscuity
//
// Great tit
//
// Southern pied babbler
//
// Cooperative breeding
//
// Inbreeding depression
//
// Outcrossing
//
// Enlarge
//
// Enlarge
//
// Gran Canaria blue chaffinch
//
// Pinus canariensis
//
// Ecological niche
//
// Forest canopy
//
// Insectivore
//
// Frugivore
//
// Nectarivore
//
// Kleptoparasitism
//
// Scavenger
//
// Avivore
//
// Coevolution
//
// Moa
//
// New Zealand pigeon
//
// Kokako
//
// Seabird
//
// Guano
//
// Avian ecology field methods
//
// Birds in culture
//
// Enlarge
//
// Enlarge
//
// Industrial farming
//
// Chicken
//
// Mutualism (biology)
//
// Honeyguide
//
// Borana people
//
// Commensalism
//
// House sparrow
//
// Bird strike
//
// Hunting
//
// Avian lead poisoning
//
// Pesticide
//
// Roadkill
//
// Wind turbine
//
// Cat
//
// Dog
//
// Psittacosis
//
// Salmonellosis
//
// Campylobacteriosis
//
// Tuberculosis
//
// Avian influenza
//
// Giardiasis
//
// Cryptosporidiosis
//
// Zoonosis
//
// Pet
//
// Enlarge
//
// Enlarge
//
// Poultry
//
// Chicken
//
// Domesticated turkey
//
// Domestic duck
//
// Domestic goose
//
// Pheasant
//
// Wild turkey
//
// Dove
//
// Partridge
//
// Grouse
//
// Snipe
//
// Woodcock
//
// Muttonbirding
//
// Down feather
//
// Guano
//
// War of the Pacific
//
// Parrot (family)
//
// Myna
//
// Aviculture
//
// Endangered species
//
// Falcon
//
// Cormorant
//
// Falconry
//
// Cormorant fishing
//
// Messenger pigeon
//
// World War II
//
// Pigeon racing
//
// Birding
//
// Bird feeder
//
// Bird feeding
//
// Enlarge
//
// Enlarge
//
// Master of the Playing Cards
//
// Deity
//
// Makemake (mythology)
//
// Tangata manu
//
// Easter Island
//
// Hugin and Munin
//
// Common raven
//
// Norse god
//
// Odin
//
// History of Italy
//
// Etruscan mythology
//
// Ancient Rome
//
// Religion in Ancient Rome
//
// Augur
//
// Religious symbolism
//
// Jonah
//
// Dove
//
// Common peacock
//
// Dravidian people
//
// Mesopotamian goddess
//
// Inanna
//
// Ancient Canaanite religion
//
// Asherah
//
// Aphrodite
//
// Ancient Greece
//
// Athena
//
// Athens
//
// Little owl
//
// Owl of Athena
//
// Enlarge
//
// Enlarge
//
// Tiles
//
// Qajar dynasty
//
// Cave painting
//
// Roc (mythology)
//
// Māori people
//
// Poukai
//
// Peacock Throne
//
// Mughal era
//
// History of Iran
//
// John James Audubon
//
// List of North American birds
//
// National Audubon Society
//
// Homer
//
// Nightingale
//
// Odyssey
//
// Catullus
//
// Sparrow
//
// Catullus 2
//
// Albatross
//
// Samuel Taylor Coleridge
//
// The Rime of the Ancient Mariner
//
// Albatross (metaphor)
//
// English language
//
// Vulture fund
//
// Owl
//
// Witchcraft
//
// Hoopoe
//
// Ancient Egypt
//
// Persia
//
// Scandinavia
//
// Heraldry
//
// Eagle (heraldry)
//
// Coats of arms
//
// Birds in music
//
// Birds in music
//
// Antonio Vivaldi
//
// Olivier Messiaen
//
// Beethoven
//
// Ottorino Respighi
//
// Beatrice Harrison
//
// David Rothenberg
//
// Enlarge
//
// Enlarge
//
// California condor
//
// Bird conservation
//
// Late Quaternary prehistoric birds
//
// List of extinct birds
//
// Raptor conservation
//
// Barn swallow
//
// European starling
//
// Extinction
//
// Melanesia
//
// Polynesia
//
// Micronesia
//
// Threatened species
//
// BirdLife International
//
// IUCN
//
// Habitat destruction
//
// Bird-skyscraper collisions
//
// Bird strike
//
// Long-line fishing
//
// Bycatch
//
// Oil spill
//
// Invasive species
//
// Conservation biology
//
// In-situ conservation
//
// Ecological restoration
//
// Ex-situ conservation
//
// California condor
//
// Norfolk parakeet
//
// Animal track
//
// Bat
//
// Glossary of bird terms
//
// Ornithology
//
// Digital object identifier
//
// PubMed Identifier
//
// Handbook of Birds of the World
//
// Lynx Edicions
//
// International Standard Book Number
//
// Special:BookSources/84-87334-10-5
//
// Carl Linnaeus
//
// Systema Naturae
//
// Zoological Journal of the Linnean Society
//
// Digital object identifier
//
// PubMed Central
//
// PubMed Identifier
//
// Kevin Padian
//
// Philip J. Currie
//
// Academic Press
//
// International Standard Book Number
//
// Special:BookSources/0-12-226810-5
//
// Category:CS1 maint: Extra text: editors list
//
// International Standard Book Number
//
// Special:BookSources/0-940228-14-9
//
// Pascal Godefroit
//
// Bibcode
//
// Digital object identifier
//
// PubMed Identifier
//
// Category:CS1 maint: Uses authors parameter
//
// Digital object identifier
//
// Science (journal)
//
// Bibcode
//
// Digital object identifier
//
// PubMed Identifier
//
// Digital object identifier
//
// PubMed Central
//
// PubMed Identifier
//
// Digital object identifier
//
// PubMed Identifier
//
// Gregory S. Paul
//
// International Standard Book Number
//
// Special:BookSources/0-8018-6763-0
//
// International Standard Book Number
//
// Special:BookSources/0-13-186266-9
//
// Science (journal)
//
// Bibcode
//
// Digital object identifier
//
// PubMed Identifier
//
// Digital object identifier
//
// PubMed Identifier
//
// Category:CS1 maint: Uses authors parameter
//
// Science (journal)
//
// Bibcode
//
// Digital object identifier
//
// PubMed Identifier
//
// Nature (journal)
//
// Bibcode
//
// Digital object identifier
//
// PubMed Identifier
//
// Digital object identifier
//
// Bibcode
//
// CiteSeerX
//
// Digital object identifier
//
// PubMed Identifier
//
// International Standard Book Number
//
// Special:BookSources/978-0-86840-413-4
//
// Bibcode
//
// Digital object identifier
//
// PubMed Identifier
//
// Digital object identifier
//
// Digital object identifier
//
// Digital object identifier
//
// PubMed Central
//
// PubMed Identifier
//
// Bibcode
//
// Digital object identifier
//
// PubMed Identifier
//
// James Clements
//
// The Clements Checklist of Birds of the World
//
// Cornell University Press
//
// International Standard Book Number
//
// Special:BookSources/978-0-8014-4501-9
//
// Frank Gill (ornithologist)
//
// Princeton University Press
//
// International Standard Book Number
//
// Special:BookSources/978-0-691-12827-6
//
// Nature (journal)
//
// Bibcode
//
// Digital object identifier
//
// PubMed Identifier
//
// Digital object identifier
//
// Bibcode
//
// Digital object identifier
//
// Category:CS1 maint: Explicit use of et al.
//
// Biology Letters
//
// Digital object identifier
//
// PubMed Central
//
// PubMed Identifier
//
// Biology Letters
//
// Digital object identifier
//
// PubMed Central
//
// PubMed Identifier
//
// Bibcode
//
// Digital object identifier
//
// PubMed Central
//
// PubMed Identifier
//
// Digital object identifier
//
// PubMed Central
//
// PubMed Identifier
//
// Charles Sibley
//
// Jon Edward Ahlquist
//
// International Standard Book Number
//
// Special:BookSources/0-300-04085-7
//
// Ernst W. Mayr
//
// OCLC
//
// Bibcode
//
// Digital object identifier
//
// PubMed Central
//
// PubMed Identifier
//
// International Standard Book Number
//
// Special:BookSources/0-12-517375-X
//
// International Standard Book Number
//
// Special:BookSources/0-19-850125-0
//
// Science (journal)
//
// Bibcode
//
// Digital object identifier
//
// PubMed Identifier
//
// International Standard Book Number
//
// Special:BookSources/0-8493-9882-7
//
// PubMed Identifier
//
// International Standard Book Number
//
// Special:BookSources/0-632-02011-3
//
// Digital object identifier
//
// Digital object identifier
//
// JSTOR
//
// Handbook of the Birds of the World
//
// International Standard Book Number
//
// Special:BookSources/84-87334-15-6
//
// Category:CS1 maint: Extra text: editors list
//
// Helm Identification Guides
//
// International Standard Book Number
//
// Special:BookSources/0-7136-6933-0
//
// Stanford University
//
// Paul Ehrlich
//
// International Standard Book Number
//
// Special:BookSources/0-7167-2415-4
//
// Digital object identifier
//
// PubMed Identifier
//
// Digital object identifier
//
// PubMed Identifier
//
// Bibcode
//
// Digital object identifier
//
// Biochemical Journal
//
// PubMed Central
//
// PubMed Identifier
//
// The American Naturalist
//
// Digital object identifier
//
// JSTOR
//
// Condor (journal)
//
// Digital object identifier
//
// JSTOR
//
// Digital object identifier
//
// Digital object identifier
//
// David Attenborough
//
// The Life of Birds
//
// International Standard Book Number
//
// Special:BookSources/0-691-01633-X
//
// Proceedings of the Royal Society B
//
// Digital object identifier
//
// PubMed Central
//
// PubMed Identifier
//
// Digital object identifier
//
// PubMed Identifier
//
// Bibcode
//
// Digital object identifier
//
// PubMed Identifier
//
// Digital object identifier
//
// Digital object identifier
//
// PubMed Identifier
//
// International Standard Book Number
//
// Special:BookSources/0-7513-5176-8
//
// Digital object identifier
//
// Biochemical Journal
//
// PubMed Central
//
// PubMed Identifier
//
// Digital object identifier
//
// International Standard Serial Number
//
// Proceedings of the Royal Society B
//
// Digital object identifier
//
// PubMed Central
//
// Bibcode
//
// Digital object identifier
//
// International Standard Book Number
//
// Special:BookSources/0-12-552455-2
//
// Digital object identifier
//
// PubMed Identifier
//
// Bibcode
//
// Digital object identifier
//
// PubMed Central
//
// PubMed Identifier
//
// Digital object identifier
//
// PubMed Identifier
//
// Bibcode
//
// Digital object identifier
//
// Bibcode
//
// Digital object identifier
//
// PubMed Identifier
//
// Digital object identifier
//
// PubMed Central
//
// PubMed Identifier
//
// Digital object identifier
//
// Digital object identifier
//
// PubMed Central
//
// PubMed Identifier
//
// Digital object identifier
//
// Digital object identifier
//
// JSTOR
//
// International Standard Book Number
//
// Special:BookSources/0-12-552455-2
//
// Digital object identifier
//
// JSTOR
//
// Digital object identifier
//
// Digital object identifier
//
// PubMed Identifier
//
// Digital object identifier
//
// Journal of Avian Biology
//
// Digital object identifier
//
// International Standard Book Number
//
// Special:BookSources/978-0-313-33545-7
//
// Digital object identifier
//
// JSTOR
//
// Digital object identifier
//
// PubMed Identifier
//
// Digital object identifier
//
// The Science of Nature
//
// Bibcode
//
// Digital object identifier
//
// PubMed Central
//
// PubMed Identifier
//
// Digital object identifier
//
// Digital object identifier
//
// JSTOR
//
// Bibcode
//
// Digital object identifier
//
// Bibcode
//
// Digital object identifier
//
// JSTOR
//
// Digital object identifier
//
// JSTOR
//
// Digital object identifier
//
// JSTOR
//
// Digital object identifier
//
// JSTOR
//
// Digital object identifier
//
// International Standard Book Number
//
// Special:BookSources/90-367-2378-7
//
// Digital object identifier
//
// PubMed Identifier
//
// Digital object identifier
//
// Handle System
//
// Digital object identifier
//
// JSTOR
//
// Digital object identifier
//
// Digital object identifier
//
// Digital object identifier
//
// PubMed Identifier
//
// International Standard Book Number
//
// Special:BookSources/0-7167-2415-4
//
// BirdLife International
//
// Bibcode
//
// Digital object identifier
//
// PubMed Central
//
// PubMed Identifier
//
// Bibcode
//
// Digital object identifier
//
// PubMed Identifier
//
// Digital object identifier
//
// Emu (journal)
//
// Digital object identifier
//
// Handbook of the Birds of the World
//
// International Standard Book Number
//
// Special:BookSources/84-87334-22-9
//
// Category:CS1 maint: Extra text: editors list
//
// PubMed Identifier
//
// PubMed Identifier
//
// Behavioral Ecology and Sociobiology
//
// Digital object identifier
//
// Digital object identifier
//
// Evolution (journal)
//
// Digital object identifier
//
// Digital object identifier
//
// Digital object identifier
//
// PubMed Identifier
//
// Bibcode
//
// Digital object identifier
//
// PubMed Identifier
//
// Digital object identifier
//
// International Standard Serial Number
//
// Journal of Zoology
//
// Digital object identifier
//
// Handbook of the Birds of the World
//
// International Standard Book Number
//
// Special:BookSources/84-96553-06-X
//
// Category:CS1 maint: Extra text: editors list
//
// Digital object identifier
//
// Oikos (journal)
//
// Digital object identifier
//
// JSTOR
//
// Digital object identifier
//
// Digital object identifier
//
// Digital object identifier
//
// JSTOR
//
// PubMed Identifier
//
// Bibcode
//
// Digital object identifier
//
// PubMed Identifier
//
// Digital object identifier
//
// JSTOR
//
// Digital object identifier
//
// Oecologia
//
// Bibcode
//
// Digital object identifier
//
// Digital object identifier
//
// Bibcode
//
// Digital object identifier
//
// PubMed Identifier
//
// Digital object identifier
//
// Digital object identifier
//
// The American Naturalist
//
// Digital object identifier
//
// The American Naturalist
//
// Digital object identifier
//
// Annual Review of Ecology, Evolution, and Systematics
//
// Digital object identifier
//
// American Zoologist
//
// Digital object identifier
//
// Digital object identifier
//
// Proceedings of the Royal Society B
//
// Digital object identifier
//
// Digital object identifier
//
// International Standard Book Number
//
// Special:BookSources/0-8050-1952-9
//
// International Standard Book Number
//
// Special:BookSources/0-394-53957-5
//
// Digital object identifier
//
// Digital object identifier
//
// Oikos (journal)
//
// Digital object identifier
//
// JSTOR
//
// International Standard Book Number
//
// Special:BookSources/0-521-46038-7
//
// Hematophagy
//
// Digital object identifier
//
// Academic Press
//
// International Standard Book Number
//
// Special:BookSources/0-12-735420-4
//
// Oxford University Press
//
// International Standard Book Number
//
// Special:BookSources/0-19-854651-3
//
// International Standard Book Number
//
// Special:BookSources/978-1-4419-8468-5
//
// International Standard Book Number
//
// Special:BookSources/978-81-7141-933-3
//
// International Standard Book Number
//
// Special:BookSources/978-1-931439-23-7
//
// Handbook of the Birds of the World
//
// International Standard Book Number
//
// Special:BookSources/84-87334-15-6
//
// Journal of Avian Biology
//
// Digital object identifier
//
// Proceedings of the Royal Society B
//
// Digital object identifier
//
// PubMed Central
//
// PubMed Identifier
//
// Ibis (journal)
//
// Digital object identifier
//
// Journal of Avian Biology
//
// Digital object identifier
//
// Handle System
//
// T. &amp; A. D. Poyser
//
// International Standard Book Number
//
// Special:BookSources/0-85661-135-2
//
// Digital object identifier
//
// Digital object identifier
//
// Bibcode
//
// Digital object identifier
//
// PubMed Central
//
// PubMed Identifier
//
// Journal of Animal Ecology
//
// Digital object identifier
//
// PubMed Identifier
//
// Bibcode
//
// Digital object identifier
//
// PubMed Identifier
//
// Digital object identifier
//
// PubMed Identifier
//
// Digital object identifier
//
// Digital object identifier
//
// PubMed Central
//
// PubMed Identifier
//
// Digital object identifier
//
// PubMed Identifier
//
// Digital object identifier
//
// PubMed Identifier
//
// Digital object identifier
//
// PubMed Identifier
//
// Digital object identifier
//
// PubMed Identifier
//
// International Standard Book Number
//
// Special:BookSources/978-0201442328
//
// Digital object identifier
//
// JSTOR
//
// Digital object identifier
//
// Digital object identifier
//
// Digital object identifier
//
// Bibcode
//
// Digital object identifier
//
// International Standard Book Number
//
// Special:BookSources/0-938027-62-X
//
// Digital object identifier
//
// JSTOR
//
// Ibis (journal)
//
// Digital object identifier
//
// National Audubon Society
//
// Digital object identifier
//
// PubMed Central
//
// PubMed Identifier
//
// International Standard Book Number
//
// Special:BookSources/978-1-84407-185-2
//
// Digital object identifier
//
// Digital object identifier
//
// Digital object identifier
//
// Digital object identifier
//
// JSTOR
//
// The Stationery Office
//
// Ibis (journal)
//
// Digital object identifier
//
// Digital object identifier
//
// PubMed Identifier
//
// Digital object identifier
//
// JSTOR
//
// Digital object identifier
//
// JSTOR
//
// International Standard Book Number
//
// Special:BookSources/0-8028-2330-0
//
// International Standard Book Number
//
// Special:BookSources/978-1-315-20160-3
//
// Wayback Machine
//
// International Standard Book Number
//
// Special:BookSources/978-0-415-77523-6
//
// International Standard Book Number
//
// Special:BookSources/978-0804725156
//
// International Standard Book Number
//
// Special:BookSources/0-299-09184-8
//
// International Standard Book Number
//
// Special:BookSources/978-9004121423
//
// International Standard Book Number
//
// Special:BookSources/0-415-30066-5
//
// Martin P. Nilsson
//
// International Standard Book Number
//
// Special:BookSources/0-8196-0273-6
//
// Digital object identifier
//
// JSTOR
//
// International Standard Book Number
//
// Special:BookSources/978-0-909010-21-8
//
// Digital object identifier
//
// JSTOR
//
// Digital object identifier
//
// JSTOR
//
// Digital object identifier
//
// JSTOR
//
// Digital object identifier
//
// Digital object identifier
//
// JSTOR
//
// Digital object identifier
//
// International Standard Book Number
//
// Special:BookSources/0-521-77191-9
//
// Oxford University Press
//
// International Standard Book Number
//
// Special:BookSources/0-19-850837-9
//
// International Standard Book Number
//
// Special:BookSources/978-0-226-77142-7
//
// BirdLife International
//
// International Standard Book Number
//
// Special:BookSources/978-0-521-78949-3
//
// Digital object identifier
//
// Digital object identifier
//
// Bibcode
//
// Digital object identifier
//
// PubMed Identifier
//
// Science (journal)
//
// Bibcode
//
// Digital object identifier
//
// PubMed Identifier
//
// Digital object identifier
//
// Wikipedia:LIBRARY
//
// File:Bird (Intro).ogg
//
// Wikipedia:Media help
//
// Wikipedia:Spoken articles
//
// Wikipedia:Wikimedia sister projects
//
// National Audubon Society
//
// Encyclopedia of Life
//
// The Auk
//
// Condor (journal)
//
// The Wilson Bulletin
//
// Template:Chordata
//
// Template talk:Chordata
//
// Chordate
//
// Animal
//
// Bilateria
//
// Deuterostome
//
// Cephalochordate
//
// Lancelet
//
// Chordate
//
// Tunicate
//
// Ascidiacea
//
// Larvacea
//
// Thaliacea
//
// Vertebrate
//
// Cyclostomata
//
// Hagfish
//
// Hyperoartia
//
// Gnathostomata
//
// Chondrichthyes
//
// Osteichthyes
//
// Actinopterygii
//
// Sarcopterygii
//
// Actinistia
//
// Rhipidistia
//
// Lungfish
//
// Tetrapod
//
// Amphibian
//
// Amniote
//
// Mammal
//
// Sauria
//
// Lepidosauria
//
// Rhynchocephalia
//
// Squamata
//
// Archelosauria
//
// Turtle
//
// Archosaur
//
// Crocodilia
//
// Sarcopterygii
//
// Reptile
//
// Template:Birds
//
// Template talk:Birds
//
// Class (biology)
//
// Anatomy
//
// Bird anatomy
//
// Bird flight
//
// Egg
//
// Feather
//
// Plumage
//
// Beak
//
// Bird vision
//
// Dactyly
//
// Uropygial gland
//
// Bird vocalization
//
// Bird intelligence
//
// Bird migration
//
// Sexual selection in birds
//
// Lek mating
//
// Seabird breeding behavior
//
// Egg incubation
//
// Brood parasite
//
// Bird nest
//
// Bird hybrid
//
// Evolution
//
// Origin of birds
//
// Origin of avian flight
//
// Evolution of birds
//
// Darwin&#39;s finches
//
// Seabird
//
// List of fossil bird genera
//
// Archaeopteryx
//
// Omnivoropterygidae
//
// Confuciusornithiformes
//
// Enantiornithes
//
// Patagopterygiformes
//
// Ambiortiformes
//
// Gansus
//
// Ichthyornithes
//
// Hesperornithes
//
// Lithornithidae
//
// Moa
//
// Elephant bird
//
// Gastornithiformes
//
// Human uses of birds
//
// Bird ringing
//
// Ornithology
//
// Bird collections
//
// Birdwatching
//
// Bird feeding
//
// Bird conservation
//
// Aviculture
//
// Waterfowl hunting
//
// Cockfight
//
// Pigeon racing
//
// Falconry
//
// Pheasantry
//
// Oology
//
// Ornithomancy
//
// List of birds
//
// List of bird genera
//
// Glossary of bird terms
//
// List of birds by population
//
// Lists of birds by region
//
// List of recently extinct birds
//
// Late Quaternary prehistoric birds
//
// List of individual birds
//
// List of fictional birds
//
// Palaeognathae
//
// Ostrich
//
// Rheidae
//
// Tinamou
//
// Kiwi
//
// Casuariiformes
//
// Neognathae
//
// Galloanserae
//
// Fowl
//
// Anseriformes
//
// Anatidae
//
// Duck
//
// Anatinae
//
// Diving duck
//
// Mergini
//
// Oxyurini
//
// Anserinae
//
// Swan
//
// Goose
//
// Whistling duck
//
// Freckled duck
//
// Tadorninae
//
// Anhimidae
//
// Anhima
//
// Chauna
//
// Anseranatidae
//
// Anatalavis
//
// Anseranas
//
// Galliformes
//
// Landfowl
//
// Gamebirds
//
// Cracidae
//
// Cracinae
//
// Oreophasinae
//
// Penelopinae
//
// Megapodidae
//
// Aepypodius
//
// Alectura
//
// Eulipoa
//
// Leipoa
//
// Macrocephalon
//
// Megapodius
//
// Talegalla
//
// Numididae
//
// Acryllium
//
// Agelastes
//
// Guttera
//
// Numida
//
// Odontophoridae
//
// Callipepla
//
// Colinus
//
// Cyrtonyx
//
// Dactylortyx
//
// Dendrortyx
//
// Odontophorus
//
// Oreortyx
//
// Philortyx
//
// Rhynchortyx
//
// Phasianidae
//
// Meleagridinae
//
// Perdicinae
//
// Phasianinae
//
// Tetraoninae
//
// Neoaves
//
// Columbea
//
// Columbimorphae
//
// Columbiformes
//
// Mesite
//
// Sandgrouse
//
// Mirandornithes
//
// Flamingo
//
// Grebe
//
// Passerea
//
// Otidimorphae
//
// Cuckoo
//
// Turaco
//
// Bustard
//
// Strisores
//
// Caprimulgiformes
//
// Steatornithiformes
//
// Podargiformes
//
// Apodiformes
//
// Opisthocomiformes
//
// Opisthocomidae
//
// Cursorimorphae
//
// Charadriiformes
//
// Gruiformes
//
// Phaethontimorphae
//
// Tropicbird
//
// Eurypygiformes
//
// Aequornithes
//
// Loon
//
// Penguin
//
// Procellariiformes
//
// Ciconiiformes
//
// Suliformes
//
// Pelecaniformes
//
// Australaves
//
// Cariamiformes
//
// Falconidae
//
// Parrot
//
// Passerine
//
// Afroaves
//
// Cathartiformes
//
// Accipitriformes
//
// Owl
//
// Mousebird
//
// Trogon
//
// Cuckoo roller
//
// Bucerotiformes
//
// Coraciiformes
//
// Piciformes
//
// Category:Birds
//
// Portal:Birds
//
// Outline of birds
//
// Template:Birds in culture
//
// Template talk:Birds in culture
//
// Human uses of birds
//
// Aviculture
//
// Birdwatching
//
// Bird conservation
//
// Fletching
//
// Cockfight
//
// Falconry
//
// Pigeon racing
//
// Vinkensport
//
// Model organism
//
// Ornithology
//
// Augury
//
// African sacred ibis
//
// Sky burial
//
// Category:Heraldic birds
//
// Corvus (heraldry)
//
// Eagle (heraldry)
//
// Martlet
//
// Turul
//
// Cormorant fishing
//
// Driven grouse shooting
//
// Plume hunting
//
// Waterfowl hunting
//
// Poultry farming
//
// Poultry farming
//
// Chicken as food
//
// Down feather
//
// Egg as food
//
// Feather
//
// Guano
//
// Poultry
//
// Bird-and-flower painting
//
// Feather tights
//
// The Conference of the Birds
//
// Ode to a Nightingale
//
// To a Skylark
//
// Crow (poetry)
//
// A History of British Birds
//
// The Tale of Jemima Puddle-Duck
//
// The Ugly Duckling
//
// The Birds (play)
//
// Swan Lake
//
// The Firebird
//
// The Birds (film)
//
// Kes (film)
//
// Category:Animated films about birds
//
// Category:Films about chickens
//
// Category:Horror films about birds
//
// Birds in music
//
// Aigrette
//
// Feather boa
//
// Feather cloak
//
// Cendrawasih (dance)
//
// Chicken
//
// Cormorant
//
// Corvus
//
// Common cuckoo
//
// Golden eagles in human culture
//
// European goldfinch
//
// Kingfisher
//
// Parrot
//
// Partridge
//
// Peafowl
//
// Cultural depictions of penguins
//
// Common pheasant
//
// Columbidae
//
// Cultural depictions of ravens
//
// Ravens of the Tower of London
//
// Sparrow
//
// Barn swallow
//
// John James Audubon
//
// The Birds of America
//
// Thomas Bewick
//
// John Gould
//
// Lars Jonsson (illustrator)
//
// John Gerrard Keulemans
//
// Edward Lear
//
// Richard Lewington (artist)
//
// Roger Tory Peterson
//
// Henry Constantine Richter
//
// Joseph Smit
//
// Archibald Thorburn
//
// Joseph Wolf
//
// Niels Krabbe
//
// Peter Scott
//
// BirdLife International
//
// Royal Society for the Protection of Birds
//
// Wildfowl &amp; Wetlands Trust
//
// Category:Birds and humans
//
// Cultural depictions of dinosaurs
//
// Human uses of living things
//
// Zoomusicology
//
// Portal:Birds in culture
//
// Template:Ornithodira
//
// Template talk:Ornithodira
//
// Avemetatarsalia
//
// Dinosauromorpha
//
// Animal
//
// Chordate
//
// Reptile
//
// Archosauria
//
// Avemetatarsalia
//
// Dinosauromorpha
//
// Pterosauromorpha
//
// Avemetatarsalia
//
// Avemetatarsalia
//
// Scleromochlus
//
// Aphanosauria
//
// Dongusuchus
//
// Spondylosoma
//
// Teleocrater
//
// Yarasuchus
//
// Ornithodira
//
// Faxinalipterus
//
// Dinosauromorpha
//
// Pterosauromorpha
//
// Teleocrater rhadinus
//
// Pterosauromorpha
//
// Scleromochlidae
//
// Scleromochlus
//
// Pterosaur
//
// Eopterosauria
//
// Peteinosaurus
//
// Preondactylia
//
// Austriadactylus
//
// Preondactylus
//
// Eudimorphodontoidea
//
// Raeticodactylidae
//
// Caviramus
//
// Raeticodactylus
//
// Eudimorphodontidae
//
// Arcticodactylus
//
// Austriadraco
//
// Eudimorphodontinae
//
// Carniadactylus
//
// Eudimorphodon
//
// Macronychoptera
//
// Dimorphodontia
//
// Caelestiventus
//
// Dimorphodon
//
// Novialoidea
//
// Campylognathoididae
//
// Bergamodactylus
//
// Campylognathoides
//
// Breviquartossa
//
// Rhamphorhynchidae
//
// Pterodactylomorpha
//
// Allkaruen
//
// Sordes
//
// Monofenestrata
//
// Campylognathoides liasicus
//
// Dinosauromorpha
//
// Lagerpetidae
//
// Dromomeron
//
// Ixalerpeton
//
// Lagerpeton
//
// Dinosauriformes
//
// Lagosuchus
//
// Marasuchus
//
// Nyasasaurus
//
// Teyuwasu
//
// Dracohors
//
// Saltopus
//
// Silesauridae
//
// Agnosphitys
//
// Asilisaurus
//
// Diodorus scytobrachion
//
// Eucoelophysis
//
// Ignotosaurus
//
// Lewisuchus
//
// Lutungutali
//
// Pisanosaurus
//
// Pseudolagosuchus
//
// Sacisaurus
//
// Silesaurus
//
// Soumyasaurus
//
// Technosaurus
//
// Dinosaur
//
// Alwalkeria
//
// Herrerasauridae
//
// Caseosaurus
//
// Chindesaurus
//
// Herrerasaurus
//
// Sanjuansaurus
//
// Staurikosaurus
//
// Sauropodomorpha
//
// Ornithischia
//
// Theropoda
//
// Silesaurus opolensis
//
// Sauropodomorpha
//
// Bagualosaurus
//
// Buriolestes
//
// Eoraptor
//
// Nyasasaurus
//
// Pampadromaeus
//
// Guaibasauridae
//
// Guaibasaurus
//
// Panphagia
//
// Saturnaliinae
//
// Chromogisaurus
//
// Saturnalia (dinosaur)
//
// Arcusaurus
//
// Asylosaurus
//
// Efraasia
//
// Nambalia
//
// Pantydraco
//
// Thecodontosaurus
//
// Plateosauria
//
// Plateosauridae
//
// Euskelosaurus
//
// Jaklapallisaurus
//
// Plateosauravus
//
// Plateosaurus
//
// Ruehleia
//
// Unaysaurus
//
// Xixiposaurus
//
// Yimenosaurus
//
// Massopoda
//
// Gryponyx
//
// Gyposaurus
//
// Riojasauridae
//
// Eucnemesaurus
//
// Riojasaurus
//
// Massospondylidae
//
// Adeopapposaurus
//
// Coloradisaurus
//
// Glacialisaurus
//
// Ignavusaurus
//
// Leyesaurus
//
// Lufengosaurus
//
// Massospondylus
//
// Pradhania
//
// Sarahsaurus
//
// Sauropodiformes
//
// Chuxiongosaurus
//
// Jingshanosaurus
//
// Seitaad
//
// Xingxiulong
//
// Yizhousaurus
//
// Yunnanosaurus
//
// Anchisauria
//
// Aardonyx
//
// Anchisaurus
//
// Lamplughsaura
//
// Leonerasaurus
//
// Mussaurus
//
// Pulanesaura
//
// Sefapanosaurus
//
// Melanorosauridae
//
// Camelotia
//
// Melanorosaurus
//
// Meroktenos
//
// Sauropoda
//
// Template:Sauropoda
//
// Massospondylus carinatus
//
// Ornithischia
//
// Chilesaurus
//
// Eocursor
//
// Fabrosaurus
//
// Heterodontosauridae
//
// Echinodon
//
// Fruitadens
//
// Tianyulong
//
// Heterodontosaurinae
//
// Abrictosaurus
//
// Heterodontosaurus
//
// Lycorhinus
//
// Manidens
//
// Pegomastax
//
// Genasauria
//
// Isaberrysaura
//
// Lesothosaurus
//
// Serendipaceratops
//
// Thyreophora
//
// Ankylosauria
//
// Stegosauria
//
// Template:Thyreophora
//
// Neornithischia
//
// Agilisaurus
//
// Hexinlusaurus
//
// Hypsilophodon
//
// Kulindadromeus
//
// Leaellynasaura
//
// Othnielosaurus
//
// Phyllodon
//
// Xiaosaurus
//
// Yandusaurus
//
// Jeholosauridae
//
// Jeholosaurus
//
// Yueosaurus
//
// Parksosauridae
//
// Orodrominae
//
// Albertadromeus
//
// Koreanosaurus
//
// Orodromeus
//
// Oryctodromeus
//
// Zephyrosaurus
//
// Thescelosaurinae
//
// Changchunsaurus
//
// Haya (dinosaur)
//
// Parksosaurus
//
// Thescelosaurus
//
// Elasmaria
//
// Cerapoda
//
// Ornithopod
//
// Iguanodontia
//
// Template:Ornithopoda
//
// Marginocephalia
//
// Template:Marginocephalia
//
// Heterodontosaurus tucki
//
// Theropoda
//
// Daemonosaurus
//
// Eodromaeus
//
// Eoraptor
//
// Tawa hallae
//
// Neotheropoda
//
// Liliensternus
//
// Tachiraptor
//
// Zupaysaurus
//
// Coelophysoidea
//
// Dolichosuchus
//
// Dracoraptor
//
// Gojirasaurus
//
// Lophostropheus
//
// Podokesaurus
//
// Powellvenator
//
// Sarcosaurus
//
// Coelophysidae
//
// Camposaurus
//
// Coelophysis
//
// Lepidus praecisio
//
// Lucianovenator
//
// Panguraptor
//
// Procompsognathus
//
// Pterospondylus
//
// Segisaurus
//
// Dilophosauridae
//
// Dilophosaurus
//
// Dracovenator
//
// Shuangbaisaurus
//
// Averostra
//
// Ceratosauria
//
// Template:Ceratosauria
//
// Tetanurae
//
// Chuandongocoelurus
//
// Cruxicheiros
//
// Cryolophosaurus
//
// Kaijiangosaurus
//
// Kayentavenator
//
// Monolophosaurus
//
// Sinosaurus
//
// Orionides
//
// Megalosauroidea
//
// Template:Megalosauroidea
//
// Avetheropoda
//
// Gasosaurus
//
// Carnosauria
//
// Template:Allosauroidea
//
// Coelurosauria
//
// Template:Coelurosauria
//
// Coelophysis bauri
//
// Category:Archosaurs
//
// Category:Birds
//
// Category:Dinosaurs
//
// Category:Pterosaurs
//
// Category:Ornithodirans
//
// Cretaceous–Paleogene extinction event
//
// Help:Taxon identifiers
//
// Wikidata
//
// Wikispecies
//
// Animal Diversity Web
//
// Encyclopedia of Life
//
// EPPO Code
//
// Fauna Europaea
//
// Fossilworks
//
// Global Biodiversity Information Facility
//
// INaturalist
//
// Integrated Taxonomic Information System
//
// National Center for Biotechnology Information
//
// World Register of Marine Species
//
// ZooBank
//
// Help:Authority control
//
// Bibliothèque nationale de France
//
// Integrated Authority File
//
// Library of Congress Control Number
//
// National Archives and Records Administration
//
// National Diet Library
//
// Help:Category
//
// Category:Birds
//
// Category:Dinosaurs
//
// Category:Santonian first appearances
//
// Category:Extant Late Cretaceous first appearances
//
// Category:Animals by common name
//
// Category:Feathered dinosaurs
//
// Category:Articles with Latin-language external links
//
// Category:CS1 maint: Extra text: editors list
//
// Category:CS1 maint: Uses authors parameter
//
// Category:CS1 maint: Explicit use of et al.
//
// Category:Webarchive template wayback links
//
// Category:Wikipedia indefinitely semi-protected pages
//
// Category:Wikipedia indefinitely move-protected pages
//
// Category:Articles with short description
//
// Category:Use dmy dates from June 2015
//
// Category:Use British English from September 2016
//
// Category:Articles with &#039;species&#039; microformats
//
// Category:Articles with hAudio microformats
//
// Category:Spoken articles
//
// Category:Featured articles
//
// Category:Wikipedia articles with BNF identifiers
//
// Category:Wikipedia articles with GND identifiers
//
// Category:Wikipedia articles with LCCN identifiers
//
// Category:Wikipedia articles with NARA identifiers
//
// Category:Wikipedia articles with NDL identifiers
//
// Discussion about edits from this IP address [n]" accesskey="n
//
// A list of edits made from this IP address [y]" accesskey="y
//
// View the content page [c]" accesskey="c
//
// Discussion about the content page [t]" accesskey="t
//
// This page is protected.&#10;You can view its source [e]" accesskey="e
//
// Visit the main page [z]" accesskey="z
//
// Guides to browsing Wikipedia
//
// Featured content – the best of Wikipedia
//
// Find background information on current events
//
// Load a random article [x]" accesskey="x
//
// Guidance on how to use and edit Wikipedia
//
// Find out about Wikipedia
//
// About the project, what you can do, where to find things
//
// A list of recent changes in the wiki [r]" accesskey="r
//
// List of all English Wikipedia pages containing links to this page [j]" accesskey="j
//
// Recent changes in pages linked from this page [k]" accesskey="k
//
// Upload files [u]" accesskey="u
//
// A list of all special pages [q]" accesskey="q
//
// Wikipedia:About
//
// Wikipedia:General disclaimer
//
// Here is your 2-th article.Listen to this article
//
// Precambrian
//
// Cambrian
//
// Ordovician
//
// Silurian
//
// Devonian
//
// Carboniferous
//
// Permian
//
// Triassic
//
// Cretaceous
//
// Paleogene
//
// Neogene
//
// Oxygen
//
// Carbon dioxide
//
// Parts per million
//
// Template:Jurassic graphical timeline
//
// Mesozoic
//
// Triassic
//
// Cretaceous
//
// Early Jurassic
//
// Middle Jurassic
//
// Late Jurassic
//
// Hettangian
//
// Sinemurian
//
// Pliensbachian
//
// Toarcian
//
// Aalenian
//
// Bajocian
//
// Bathonian
//
// Callovian
//
// Oxfordian (stage)
//
// Kimmeridgian
//
// Tithonian
//
// Help:IPA/English
//
// Jura Mountains
//
// Period (geology)
//
// Triassic
//
// Annum
//
// Cretaceous
//
// Mesozoic Era
//
// Triassic–Jurassic extinction event
//
// Extinction
//
// Toarcian turnover
//
// Tithonian
//
// Extinction event
//
// Epoch (geology)
//
// Stratigraphy
//
// Lower Jurassic
//
// Middle Jurassic
//
// Upper Jurassic
//
// Series (stratigraphy)
//
// Jura Mountains
//
// European Alps
//
// Limestone
//
// Supercontinent
//
// Pangaea
//
// Rift
//
// Laurasia
//
// Gondwana
//
// Arid
//
// Dinosauromorpha
//
// Crocodylomorpha
//
// Archosaur
//
// Dinosaur
//
// Bird
//
// Theropod
//
// Theria
//
// Placental
//
// Marine reptiles
//
// Ichthyosaur
//
// Plesiosaur
//
// Pterosaur
//
// Vertebrates
//
// Chronostratigraphy
//
// Jura Mountains
//
// Mountain range
//
// France–Switzerland border
//
// Alexander von Humboldt
//
// Limestone
//
// Abraham Gottlob Werner
//
// Epoch (geology)
//
// Stratigraphy
//
// Lower Jurassic
//
// Middle Jurassic
//
// Upper Jurassic
//
// Series (stratigraphy)
//
// Europe
//
// Leopold von Buch
//
// Faunal stage
//
// Late Jurassic
//
// Tithonian
//
// Annum
//
// Kimmeridgian
//
// Oxfordian stage
//
// Middle Jurassic
//
// Callovian
//
// Bathonian
//
// Bajocian
//
// Aalenian
//
// Early Jurassic
//
// Toarcian
//
// Pliensbachian
//
// Sinemurian
//
// Hettangian
//
// Enlarge
//
// Enlarge
//
// St. George, Utah
//
// Dilophosaurus
//
// Supercontinent
//
// Pangaea
//
// Laurasia
//
// Gondwana
//
// Gulf of Mexico
//
// North America
//
// Yucatan Peninsula
//
// Atlantic Ocean
//
// Tethys Ocean
//
// Mediterranean Basin
//
// Glacier
//
// Europe
//
// Jurassic Coast
//
// World Heritage Site
//
// Lagerstätte
//
// Holzmaden
//
// Solnhofen limestone
//
// Epeiric Sea
//
// Sundance Sea
//
// Alluvium
//
// Morrison Formation
//
// Calcite sea
//
// Calcite
//
// Carbonate hardgrounds
//
// Ooids
//
// Batholith
//
// American cordillera
//
// Nevadan orogeny
//
// Tendaguru Formation
//
// Paleobiota of the Morrison Formation
//
// Morrison Formation
//
// Matmor Formation
//
// Matmor Formation
//
// Israel
//
// Morrison Formation
//
// Morrison Formation
//
// Colorado
//
// Dinosaur
//
// Dinosaur
//
// Moenave Formation
//
// Utah
//
// Permian
//
// Permian
//
// Colorado Plateau
//
// Utah
//
// Fish
//
// Reptile
//
// Ichthyosaur
//
// Plesiosauria
//
// Pliosaur
//
// Crocodilia
//
// Teleosauridae
//
// Metriorhynchidae
//
// Turtle
//
// Invertebrate
//
// Rudists
//
// Reef
//
// Bivalvia
//
// Belemnitida
//
// Sabellidae
//
// Glomerula
//
// Bioerosion
//
// Bioerosion
//
// Ichnotaxa
//
// Trace fossil
//
// Gastrochaenolites
//
// Clade
//
// Pliosaurus
//
// Pliosaurus
//
// Leedsichthys
//
// Ichthyosaurus
//
// Ichthyosaurus
//
// Germany
//
// Dolphin
//
// Plesiosaur
//
// Plesiosaur
//
// Muraenosaurus
//
// Gastropod
//
// Gastropod
//
// Bivalve
//
// Israel
//
// Enlarge
//
// Enlarge
//
// Drzewica Formation
//
// Szydłowiec
//
// Poland
//
// Archosaur
//
// Sauropod
//
// Camarasaurus
//
// Apatosaurus
//
// Diplodocus
//
// Brachiosaurus
//
// Prairie
//
// Fern
//
// Cycad
//
// Bennettitales
//
// Ornithischia
//
// Stegosaur
//
// Ornithopod
//
// Theropod
//
// Ceratosaurus
//
// Megalosaurus
//
// Torvosaurus
//
// Allosaurus
//
// Saurischia
//
// Dinosaur
//
// Aves
//
// Archaeopteryx
//
// Evolution
//
// Coelurosaur
//
// Pterosaur
//
// Bird
//
// Mammals
//
// Tritylodontidae
//
// Sphenodontia
//
// Lissamphibia
//
// Lissamphibia
//
// Salamander
//
// Caecilian
//
// Diplodocus
//
// Diplodocus
//
// Sauropod
//
// Allosaurus
//
// Allosaurus
//
// Stegosaurus
//
// Stegosaurus
//
// Archaeopteryx
//
// Archaeopteryx
//
// Late Jurassic
//
// Aurornis xui
//
// Aurornis xui
//
// Basal (phylogenetics)
//
// Avialan
//
// Enlarge
//
// Enlarge
//
// Conifer
//
// Enlarge
//
// Enlarge
//
// Conifer
//
// Triassic
//
// Gymnosperm
//
// Conifers
//
// Araucariaceae
//
// Cephalotaxaceae
//
// Pinaceae
//
// Podocarpaceae
//
// Taxaceae
//
// Taxodiaceae
//
// Cheirolepidiaceae
//
// Bennettitales
//
// Cycad
//
// Ginkgo
//
// Dicksoniaceae
//
// Tree ferns
//
// Fern
//
// Caytoniaceae
//
// Podocarps
//
// Ginkgo
//
// Coralline algae
//
// Portal:Jurassic
//
// Black Jurassic
//
// Brown Jurassic
//
// White Jurassic
//
// Jurassic Park
//
// Portal:Jurassic
//
// Portal:Jurassic
//
// Portal:Mesozoic
//
// Portal:Mesozoic
//
// Portal:Geology
//
// Portal:Geology
//
// Portal:Paleontology
//
// Portal:Paleontology
//
// Portal:Time
//
// Portal:Time
//
// Vaca Muerta
//
// Neuquén Basin
//
// Víctor Alberto Ramos
//
// International Union of Geological Sciences
//
// File:Sauerstoffgehalt-1000mj.svg
//
// File:OxygenLevel-1000ma.svg
//
// File:Phanerozoic Carbon Dioxide.png
//
// File:All palaeotemps.png
//
// Víctor Alberto Ramos
//
// Gondwana Research
//
// Bibcode
//
// Digital object identifier
//
// Bibcode
//
// Digital object identifier
//
// Bibcode
//
// Digital object identifier
//
// PubMed Identifier
//
// Digital object identifier
//
// Digital object identifier
//
// Bibcode
//
// Digital object identifier
//
// International Standard Book Number
//
// Special:BookSources/978-0-7894-5187-3
//
// International Standard Book Number
//
// Special:BookSources/978-0-300-06460-5
//
// International Standard Book Number
//
// Special:BookSources/978-0-7167-1822-2
//
// University of Chicago Press
//
// International Standard Book Number
//
// Special:BookSources/0-226-04154-9
//
// International Standard Book Number
//
// Special:BookSources/0-226-04155-7
//
// International Standard Book Number
//
// Special:BookSources/0-563-38449-2
//
// International Standard Book Number
//
// Special:BookSources/0-314-09577-2
//
// Bibcode
//
// Digital object identifier
//
// Bibcode
//
// Digital object identifier
//
// File:Jurassic spoken article.ogg
//
// Wikipedia:Media help
//
// Wikipedia:Spoken articles
//
// Template:Jurassic Footer
//
// Template talk:Jurassic Footer
//
// Early Jurassic
//
// Middle Jurassic
//
// Late Jurassic
//
// Hettangian
//
// Sinemurian
//
// Pliensbachian
//
// Toarcian
//
// Aalenian
//
// Bajocian
//
// Bathonian
//
// Callovian
//
// Oxfordian (stage)
//
// Kimmeridgian
//
// Tithonian
//
// Template:Geological history
//
// Template talk:Geological history
//
// Geologic time scale
//
// Cenozoic
//
// Quaternary
//
// Holocene
//
// Pleistocene
//
// Neogene
//
// Pliocene
//
// Miocene
//
// Paleogene
//
// Oligocene
//
// Eocene
//
// Paleocene
//
// Mesozoic
//
// Cretaceous
//
// Late Cretaceous
//
// Early Cretaceous
//
// Late Jurassic
//
// Middle Jurassic
//
// Early Jurassic
//
// Triassic
//
// Late Triassic
//
// Middle Triassic
//
// Early Triassic
//
// Paleozoic
//
// Permian
//
// Lopingian
//
// Guadalupian
//
// Cisuralian
//
// Carboniferous
//
// Pennsylvanian (geology)
//
// Mississippian (geology)
//
// Devonian
//
// Late Devonian
//
// Middle Devonian
//
// Early Devonian
//
// Silurian
//
// Pridoli epoch
//
// Ludlow epoch
//
// Wenlock (Silurian)
//
// Llandovery epoch
//
// Ordovician
//
// Late Ordovician
//
// Middle Ordovician
//
// Early Ordovician
//
// Cambrian
//
// Furongian
//
// Miaolingian
//
// Cambrian Series 2
//
// Terreneuvian
//
// Proterozoic
//
// Neoproterozoic
//
// Ediacaran
//
// Cryogenian
//
// Tonian
//
// Mesoproterozoic
//
// Stenian
//
// Ectasian
//
// Calymmian
//
// Paleoproterozoic
//
// Statherian
//
// Orosirian
//
// Rhyacian
//
// Siderian
//
// Archean
//
// Neoarchean
//
// Mesoarchean
//
// Paleoarchean
//
// Eoarchean
//
// Hadean
//
// Tya (unit)
//
// Mya (unit)
//
// Billion years
//
// Help:Authority control
//
// Integrated Authority File
//
// National Diet Library
//
// Help:Category
//
// Category:Jurassic
//
// Category:Mesozoic
//
// Category:Geological periods
//
// Category:Mesozoic geochronology
//
// Category:CS1 Spanish-language sources (es)
//
// Category:Periods with timeline in infobox
//
// Category:Spoken articles
//
// Category:Articles with hAudio microformats
//
// Category:Wikipedia articles with GND identifiers
//
// Category:Wikipedia articles with NDL identifiers
//
// Discussion about edits from this IP address [n]" accesskey="n
//
// A list of edits made from this IP address [y]" accesskey="y
//
// View the content page [c]" accesskey="c
//
// Discussion about the content page [t]" accesskey="t
//
// Edit this page [e]" accesskey="e
//
// Visit the main page [z]" accesskey="z
//
// Guides to browsing Wikipedia
//
// Featured content – the best of Wikipedia
//
// Find background information on current events
//
// Load a random article [x]" accesskey="x
//
// Guidance on how to use and edit Wikipedia
//
// Find out about Wikipedia
//
// About the project, what you can do, where to find things
//
// A list of recent changes in the wiki [r]" accesskey="r
//
// List of all English Wikipedia pages containing links to this page [j]" accesskey="j
//
// Recent changes in pages linked from this page [k]" accesskey="k
//
// Upload files [u]" accesskey="u
//
// A list of all special pages [q]" accesskey="q
//
// Wikipedia:About
//
// Wikipedia:General disclaimer

int main(int argc, char* argv[]){
  for(int i =1; i<argc; i++){
    printf("Here is your %d-th article.\n", i);
    char* fname = argv[i];
    FILE *fpointer;

    fpointer = fopen(fname, "r+");
    if(fpointer == NULL){
        printf("ERROR MESSAGE: The file does not exist");
        return -1;
    }
    size_t l;
    fseek(fpointer, 0 , SEEK_END);
    l = ftell(fpointer);
    rewind(fpointer);

    char s[l+1];
    fread(s, 1, l+1, fpointer);
    s[l] = '\0';
    char *begin = s;
    char *timeStamp = begin;
    char *end;
    char *nestedBegin;
    char *nestedEnd;


    //We iterate through the whole file
    while(1)
    {

     begin = strstr(timeStamp, "<a href=\"/wiki/");
        if(begin == NULL)
        {
            break;
        }
        end= strstr(begin,"</a>");
        if(end == NULL)
        {
            break;
        }
        size_t sizelabRat = end - begin;
        char labRat[sizelabRat];
        strncpy(labRat, begin, sizelabRat);
        labRat[sizelabRat] = '\0';
        char *d;
        if((d = strstr(labRat + 18, "<a href=\"/wiki/" )) != NULL)
        {timeStamp = begin + 18;
          continue;

        }
        nestedBegin = strstr(begin, "title=\"");
        nestedEnd = strstr(nestedBegin, "\">");
        if(nestedBegin != NULL && nestedEnd != NULL)
        {size_t nestedSize= nestedEnd - (nestedBegin + 7);
          char pageTitle[nestedSize];
          strncpy(pageTitle, nestedBegin + 7, nestedEnd - (nestedBegin + 7));
          pageTitle[nestedSize] = '\0';

            printf("%s \n", pageTitle);
        }
        timeStamp = begin + 18;
        printf("\n");

    }
      fclose(fpointer);

    }
  return 0;
}
